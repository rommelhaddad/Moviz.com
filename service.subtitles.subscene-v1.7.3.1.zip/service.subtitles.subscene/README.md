service.subtitles.subscene
==========================

Subscene.com subtitle service plugin for XBMC

Forum thread: http://forum.xbmc.org/showthread.php?tid=184854
